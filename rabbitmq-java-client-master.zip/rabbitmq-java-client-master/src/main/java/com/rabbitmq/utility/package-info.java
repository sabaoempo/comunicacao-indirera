/**
 * Utility package of helper classes, mostly used in the implementation code.
 */
package com.rabbitmq.utility;