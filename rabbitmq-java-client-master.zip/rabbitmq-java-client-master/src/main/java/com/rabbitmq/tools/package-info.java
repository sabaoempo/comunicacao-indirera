/**
 * Non-core utilities and administration tools.
 */
package com.rabbitmq.tools;