/**
 * JSON-RPC client and server classes for supporting JSON-RPC over an AMQP transport.
 */
package com.rabbitmq.tools.jsonrpc;