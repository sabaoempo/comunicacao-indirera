/**
 * JSON reader/writer and utility classes.
 */
package com.rabbitmq.tools.json;