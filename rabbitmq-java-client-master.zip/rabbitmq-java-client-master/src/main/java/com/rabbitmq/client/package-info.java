/**
 * The client API proper: classes and interfaces representing the AMQP
 * connections, channels, and wire-protocol framing descriptors.
 */
package com.rabbitmq.client;