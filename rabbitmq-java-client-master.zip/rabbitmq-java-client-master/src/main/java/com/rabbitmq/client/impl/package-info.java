/**
 * Implementations of interfaces specified in the client API, and their supporting classes.
 */
package com.rabbitmq.client.impl;