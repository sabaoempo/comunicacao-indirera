/**
 * NIO network connector.
 */
package com.rabbitmq.client.impl.nio;