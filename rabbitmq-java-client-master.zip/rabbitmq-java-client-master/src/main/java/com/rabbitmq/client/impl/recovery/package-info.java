/**
 * Implementation of connection and topology recovery.
 */
package com.rabbitmq.client.impl.recovery;